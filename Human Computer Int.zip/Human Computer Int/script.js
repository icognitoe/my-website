// JavaScript logic for the ecommerce functionality
// You can use localStorage to store the product data and basket items

// Sample product data
const allProducts = [
    // Phones
    { id: 1, name: "iPhone 11 Pro", category: "Phones", price: "£756" },
    { id: 2, name: "iPhone 13 Pro", category: "Phones", price: "£1120" },
    { id: 3, name: "iPhone 13", category: "Phones", price: "£989" },
    // Laptops
    { id: 4, name: "Dell Laptop", category: "Laptops", price: "£1200" },
    { id: 5, name: "hp", category: "Laptops", price: "£360" },
    { id: 6, name: "Macbook", category: "Laptops", price: "£2000" },
    // Consoles
    { id: 7, name: "PS5", category: "Consoles", price: "£499.99" },
    { id: 8, name: "PS4", category: "Consoles", price: "£289.99" },
    { id: 9, name: "XBox 1", category: "Consoles", price: "£498.99" },
    { id: 10, name: "XBox 360", category: "Consoles", price: "£199.99" },
    { id: 11, name: "Fifa 24", category: "Consoles", price: "£60.00" },
    // Women's Clothing
    { id: 12, name: "Dress", category: "Women's Clothing", price: "£29.99" },
    { id: 13, name: "Blouse", category: "Women's Clothing", price: "£19.99" },
    { id: 14, name: "Skirt", category: "Women's Clothing", price: "£24.99" },
    // Men's Clothing
    { id: 15, name: "Shirt", category: "Men's Clothing", price: "£34.99" },
    { id: 16, name: "Jeans", category: "Men's Clothing", price: "£39.99" },
    { id: 17, name: "T-Shirt", category: "Men's Clothing", price: "£14.99" },
    // Kids' Clothing
    { id: 18, name: "Dress", category: "Kids' Clothing", price: "£19.99" },
    { id: 19, name: "Trousers", category: "Kids' Clothing", price: "£24.99" },
    { id: 20, name: "Jacket", category: "Kids' Clothing", price: "£29.99" },
    // Frozen Food
    { id: 21, name: "Frozen Pizza", category: "Frozen Food", price: "£3.99" },
    { id: 22, name: "Frozen Vegetables", category: "Frozen Food", price: "£2.49" },
    { id: 23, name: "Ice Cream", category: "Frozen Food", price: "£4.99" },
    // Cupboard Food
    { id: 24, name: "Pasta", category: "Cupboard Food", price: "£1.49" },
    { id: 25, name: "Rice", category: "Cupboard Food", price: "£1.99" },
    { id: 26, name: "Cereal", category: "Cupboard Food", price: "£2.99" },
    // Ready Made Food
    { id: 27, name: "Instant Noodles", category: "Ready Made Food", price: "£0.99" },
    { id: 28, name: "Canned Soup", category: "Ready Made Food", price: "£1.99" },
    { id: 29, name: "Microwave Popcorn", category: "Ready Made Food", price: "£2.49" }
    // Add more products for each category as needed
];

// Function to toggle the display of the category dropdown menu
function toggleDropdown() {
    const dropdownMenu = document.getElementById('category-dropdown');
    dropdownMenu.classList.toggle('show');
}

// Prevent automatic closing of dropdown menu when clicking outside of it
document.getElementById('category-dropdown').onclick = function(event) {
    event.stopPropagation();
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
    const dropdownMenu = document.getElementById('category-dropdown');
    if (!event.target.matches('.dropdown') && !dropdownMenu.contains(event.target)) {
        dropdownMenu.classList.remove('show');
    }
}

const categoryItems = document.querySelectorAll('.dropdown-menu a');
categoryItems.forEach(item => {
    item.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default link behavior
        const page = this.getAttribute('href');
        window.location.href = page; // Redirect to the clicked page
    });
});

function displayProducts() {
    const productGrid = document.querySelector('.product-grid');
    productGrid.innerHTML = '';

    // Loop through each product and create HTML elements for them
    allProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.classList.add('product-card');
        productCard.innerHTML = `
            <div class="product-image">
                <!-- Placeholder image or leave it blank if you don't have images -->
            </div>
            <div class="product-info">
                <h2>${product.name}</h2>
                <p class="price">${product.price}</p>
                <button onclick="addToBasket(${product.id})">Add to Basket</button>
            </div>
        `;
        productGrid.appendChild(productCard);
    });
}


function addToBasket(productId) {
    let basketItems = JSON.parse(localStorage.getItem('basket')) || [];

    // Find the product in the allProducts array by its id
    const product = allProducts.find(item => item.id === productId);

    if (product) {
        basketItems.push(product);
        
        // Update the basket items in localStorage
        localStorage.setItem('basket', JSON.stringify(basketItems));

        // Redirect to the basket page
        window.location.href = 'basket.html';
    } else {
        console.error('Product not found!');
    }
}


function removeFromBasket(productId) {
    let basketItems = JSON.parse(localStorage.getItem('basket')) || [];
    const index = basketItems.findIndex(item => item.id === productId);
    if (index !== -1) {
        basketItems.splice(index, 1);
        localStorage.setItem('basket', JSON.stringify(basketItems));
        displayBasketItems(); // Refresh the displayed basket items after removal
    }
}


// Sample function to display basket items on the basket page
function displayBasketItems() {
    const basketItemsContainer = document.querySelector('.basket-items');
    basketItemsContainer.innerHTML = '';
    
    let basketItems = JSON.parse(localStorage.getItem('basket')) || [];

    // Check if there are items in the basket
    if (basketItems.length === 0) {
        basketItemsContainer.innerHTML = '<p>Your basket is empty.</p>';
        return;
    }

    // Iterate through each item in the basket and create HTML elements to display them
    basketItems.forEach(item => {
        const itemElement = document.createElement('div');
        itemElement.classList.add('basket-item');
        itemElement.innerHTML = `
            <h3>${item.name}</h3>
            <p>Price: ${item.price}</p>
            <button onclick="removeFromBasket(${item.id})">Remove</button>
        `;
        basketItemsContainer.appendChild(itemElement);
    });

    const totalAmount = basketItems.reduce((total, item) => total + parseFloat(item.price.replace('£', '')), 0);
    document.querySelector('.total').innerHTML = `<p>Total: £${totalAmount.toFixed(2)}</p>`;
}

window.onload = displayBasketItems();


// Function to populate the product grid based on the selected category
function populateProductGrid(category) {
    const filteredProducts = allProducts.filter(product => product.category === category);
    const productGrid = document.querySelector('.product-grid');
    productGrid.innerHTML = '';
    filteredProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.classList.add('product-card');
        productCard.innerHTML = `
            <h3>${product.name}</h3>
            <p>Price: ${product.price}</p>
            <button onclick="addToBasket(${product.id})">Add to Basket</button>
        `;
        productGrid.appendChild(productCard);
    });
}

// Call function to display products
displayProducts();

